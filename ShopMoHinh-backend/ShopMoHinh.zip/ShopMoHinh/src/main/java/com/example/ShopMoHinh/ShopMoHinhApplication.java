package com.example.ShopMoHinh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopMoHinhApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopMoHinhApplication.class, args);
	}

}
