package com.example.ShopMoHinh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopMoHinhApplicationTests {

	@Test
	void contextLoads() {
	}

}
